/* Irune Guinea Zufiaurre
 * 2023/02/07 * 
 * Problem solving:
 * Even though you showed us different possible solutions, I didn't know how to check if the class was the one I needed
 * but google helped with that, ant the getVersion is deprecated but it works */

package actividad1;

import java.security.MessageDigest;
import java.security.Provider;
import java.security.Provider.Service;
import java.security.Security;
import java.util.Set;

public class Actividad1{
	
	public static void main(String[] args) {
		
		Provider p = Security.getProvider("SUN"); //Set the provider to SUN
		
		System.out.println("** Proveedor " + p.getName() + ", versión " + p.getVersion() + " ** ");
		
		Set<Service> s = p.getServices(); //getServices returns a set
		
		for (Service service : s) { // We go through the set to print it if its a MessageDigest
			if(service.getType().equals(MessageDigest.class.getSimpleName())) { 
				System.out.println("\tNombre del algoritmo: \"" + service.getAlgorithm() + "\""); 
			}
		}
		
	}

}
