/* No problem solving needed, as we did it with Ernesto */

package actividad2;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

public class Actividad2 {
	public static void main(String[] args) {
		
		try {
			// Read public key from file
			FileInputStream inpub;
			inpub = new FileInputStream("clave.publica");
			byte[] bufferPub = new byte[inpub.available()];
			inpub.read(bufferPub);
			inpub.close();
			
			// retrieve X509 public key
			KeyFactory keyDSA = KeyFactory.getInstance("DSA");
			X509EncodedKeySpec clavePubSpec = new X509EncodedKeySpec(bufferPub);
			PublicKey clavePublica =keyDSA.generatePublic(clavePubSpec);
			
			//read file
			FileInputStream firmafic = new FileInputStream("FICHERO.FIRMA");
			byte[] firma = new byte[firmafic.available()];
			firmafic.read(firma);
			firmafic.close();
			
			//initialize object
			Signature dsa = Signature.getInstance("SHA1withDSA");
			dsa.initVerify(clavePublica);
			
			//read file 
			FileInputStream fichero = new FileInputStream("FICHERO.DAT");
			BufferedInputStream bis = new BufferedInputStream(fichero);
			byte[] buffer = new byte[bis.available()];
			int len;
			
			while((len = bis.read(buffer)) >= 0) dsa.update(buffer,0,len);
			bis.close();
			
			boolean verifica = dsa.verify(firma);
			
			//check
			if(verifica)
				System.out.println("LOS DATOS SE CORRRESPONDEN CON SU FIRMA");
			else
				System.out.println("LOS DATOS NO SE CORRESPONDEN CON SU FIRMA ");
			
		} catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException | SignatureException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
